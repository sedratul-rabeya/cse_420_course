#include <windows.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>

// Rotation angle
float angle = 0.0f;

// Draw filled circle
void drawCircle(float cx, float cy, float r, int segments = 100) {
    glBegin(GL_POLYGON);
    for (int i = 0; i < segments; i++) {
        float theta = 2.0f * 3.1415926f * i / segments;
        float x = r * cosf(theta);
        float y = r * sinf(theta);
        glVertex2f(cx + x, cy + y);
    }
    glEnd();
}


void drawText(const char* text, float x, float y) {
    glRasterPos2f(x, y);
    for (int i = 0; text[i] != '\0'; i++) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, text[i]);
    }
}


void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    glPushMatrix();


  /*  glTranslatef(0.5f, 0.5f, 0.0f);
    glRotatef(angle, 0.0f, 1.0f, 0.0f);
    glTranslatef(-0.5f, -0.5f, 0.0f);*/

    // Draw a white rectangle
    drawText("Sky", 0.25f, 1.0f);
    glColor3f(0.701f,0.898f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.0f, 0.22f);
    glVertex2f(1.0f, 0.22f);
    glVertex2f(1.0f, 1.0f);
    glVertex2f(0.0f, 1.0f);
    glEnd();

    glColor3f(0.2f,0.298f, 0.4f); // FIRST BUILDING
    glBegin(GL_QUADS);
    glVertex2f(0.05f, 0.22f);
    glVertex2f(0.2f, 0.22f);
    glVertex2f(0.2f, 0.60f);
    glVertex2f(0.05f, 0.60f);
    glEnd();


     //windows

    glColor3f(0.901f,0.901f, 0.701f); // FIRST BUILDING
    glBegin(GL_QUADS);
    glVertex2f(0.08f, 0.25f);
    glVertex2f(0.18f, 0.25f);
    glVertex2f(0.18f, 0.35f);
    glVertex2f(0.08f, 0.35f);
    glEnd();

    glColor3f(0.901f,0.901f, 0.701f); // FIRST BUILDING
    glBegin(GL_QUADS);
    glVertex2f(0.08f, 0.38f);
    glVertex2f(0.18f, 0.38f);
    glVertex2f(0.18f, 0.48f);
    glVertex2f(0.08f, 0.48f);
    glEnd();
      glColor3f(0.196f,0.588f, 0.4f); // SECOND BUILDING
    glBegin(GL_QUADS);
    glVertex2f(0.25f, 0.22f);
    glVertex2f(0.4f, 0.22f);
    glVertex2f(0.4f, 0.50f);
    glVertex2f(0.25f, 0.50f);
    glEnd();

     //windows

     glColor3f(0.901f,0.901f, 0.701f);// FIRST BUILDING
    glBegin(GL_QUADS);
    glVertex2f(0.27f, 0.25f);
    glVertex2f(0.35f, 0.25f);
    glVertex2f(0.35f, 0.35f);
    glVertex2f(0.27f, 0.35f);
    glEnd();

      glColor3f(0.901f,0.901f, 0.701f);// FIRST BUILDING
    glBegin(GL_QUADS);
    glVertex2f(0.27f, 0.38f);
    glVertex2f(0.35f, 0.38f);
    glVertex2f(0.35f, 0.48f);
    glVertex2f(0.27f, 0.48f);
    glEnd();
    glColor3f(0.4f,0.701f, 0.701f); // THIRD BUILDING
    glBegin(GL_QUADS);
    glVertex2f(0.45f, 0.22f);
    glVertex2f(0.6f, 0.22f);
    glVertex2f(0.6f, 0.60f);
    glVertex2f(0.45f, 0.60f);
    glEnd();
     //windows

      glColor3f(0.901f,0.901f, 0.701f);// FIRST BUILDING
    glBegin(GL_QUADS);
    glVertex2f(0.47f, 0.25f);
    glVertex2f(0.58f, 0.25f);
    glVertex2f(0.58f, 0.35f);
    glVertex2f(0.47f, 0.35f);
    glEnd();

      glColor3f(0.901f,0.901f, 0.701f);// FIRST BUILDING
    glBegin(GL_QUADS);
    glVertex2f(0.47f, 0.38f);
    glVertex2f(0.58f, 0.38f);
    glVertex2f(0.58f, 0.48f);
    glVertex2f(0.47f, 0.48f);
    glEnd();
      glColor3f(0.701f,0.301f, 0.203f); // FOURTH BUILDING
    glBegin(GL_QUADS);
    glVertex2f(0.65f, 0.22f);
    glVertex2f(0.8f, 0.22f);
    glVertex2f(0.8f, 0.55f);
    glVertex2f(0.65f, 0.55f);
    glEnd();
     //windows

     glColor3f(0.901f,0.901f, 0.701f); // FIRST BUILDING
    glBegin(GL_QUADS);
    glVertex2f(0.66f, 0.25f);
    glVertex2f(0.75f, 0.25f);
    glVertex2f(0.75f, 0.35f);
    glVertex2f(0.66f, 0.35f);
    glEnd();

      glColor3f(0.901f,0.901f, 0.701f);// FIRST BUILDING
    glBegin(GL_QUADS);
    glVertex2f(0.66f, 0.38f);
    glVertex2f(0.75f, 0.38f);
    glVertex2f(0.75f, 0.48f);
    glVertex2f(0.66f, 0.48f);
    glEnd();
      glColor3f(0.0f,0.198f, 0.1f); // FIFTH BUILDING
    glBegin(GL_QUADS);
    glVertex2f(0.81f, 0.22f);
    glVertex2f(0.95, 0.22f);
    glVertex2f(0.95f, 0.58f);
    glVertex2f(0.81f, 0.58f);
    glEnd();

     //windows

    glColor3f(0.901f,0.901f, 0.701f); // FIRST BUILDING
    glBegin(GL_QUADS);
    glVertex2f(0.83f, 0.25f);
    glVertex2f(0.92f, 0.25f);
    glVertex2f(0.92f, 0.35f);
    glVertex2f(0.83f, 0.35f);
    glEnd();

    glColor3f(0.901f,0.901f, 0.701f);// FIRST BUILDING
    glBegin(GL_QUADS);
    glVertex2f(0.83f, 0.38f);
    glVertex2f(0.92f, 0.38f);
    glVertex2f(0.92f, 0.48f);
    glVertex2f(0.83f, 0.48f);
    glEnd();





    glColor3f(1.f,1.0f, 1.0f); // white road
    glBegin(GL_QUADS);
    glVertex2f(0.0f, 0.17f);
    glVertex2f(1.0f, 0.17f);
    glVertex2f(1.0f, 0.22f);
    glVertex2f(0.0f, 0.22f);
    glEnd();

    glColor3f(1.f,1.0f, 1.0f); // white road
    glBegin(GL_QUADS);
    glVertex2f(0.1f, 0.09f);
    glVertex2f(0.20f, 0.09f);
    glVertex2f(0.20f, 0.11f);
    glVertex2f(0.1f, 0.11f);
    glEnd();


   glColor3f(1.f,1.0f, 1.0f); // white road
    glBegin(GL_QUADS);
    glVertex2f(0.3f, 0.09f);
    glVertex2f(0.4f, 0.09f);
    glVertex2f(0.4f, 0.11f);
    glVertex2f(0.3f, 0.11f);
    glEnd();

 glColor3f(1.f,1.0f, 1.0f); // white road
    glBegin(GL_QUADS);
    glVertex2f(0.5f, 0.09f);
    glVertex2f(0.6f, 0.09f);
    glVertex2f(0.6f, 0.11f);
    glVertex2f(0.5f, 0.11f);
    glEnd();

    glColor3f(1.f,1.0f, 1.0f); // white road
    glBegin(GL_QUADS);
    glVertex2f(0.7f, 0.09f);
    glVertex2f(0.8f, 0.09f);
    glVertex2f(0.8f, 0.11f);
    glVertex2f(0.7f, 0.11f);
    glEnd();

   /* drawText("Sky", 0.25f, 0.05f);*/

   /* // Draw a red triangle
    glColor3f(1.0f, 0.0f, 0.0f); // Red color
    glBegin(GL_TRIANGLES);
    glVertex2f(0.6f, 0.2f);
    glVertex2f(0.8f, 0.2f);
    glVertex2f(0.7f, 0.5f);
    glEnd();
    drawText("Triangle", 0.65f, 0.15f);

    // Draw a blue trapezoid
    glColor3f(0.0f, 0.0f, 1.0f); // Blue color
    glBegin(GL_QUADS);
    glVertex2f(0.2f, 0.6f);
    glVertex2f(0.5f, 0.6f);
    glVertex2f(0.4f, 0.8f);
    glVertex2f(0.3f, 0.8f);
    glEnd();
    drawText("Trapezoid", 0.35f, 0.55f);

    // Draw a green pentagon
    glColor3f(0.0f, 1.0f, 0.0f); // Green color
    glBegin(GL_POLYGON);
    glVertex2f(0.7f, 0.6f);
    glVertex2f(0.9f, 0.6f);
    glVertex2f(0.85f, 0.75f);
    glVertex2f(0.75f, 0.85f);
    glVertex2f(0.65f, 0.75f);
    glEnd();
    drawText("Pentagon", 0.75f, 0.55f);
    drawText("420 course is so much fun", 0.75f, 0.45f);*/
    // draw bird


    // Set color to black
    glColor3f(0.0f, 0.0f, 0.0f);

    glBegin(GL_LINES);  //draw a bird
    glVertex2f(0.1f, 0.8f);
    glVertex2f(0.15f, 0.78f);
    glVertex2f(0.15f, 0.78f);
    glVertex2f(0.2f, 0.8f);

    glEnd();

     // second bird
    glColor3f(0.0f, 0.0f, 0.0f);

    glBegin(GL_LINES);  //draw a bird
    glVertex2f(0.55f, 0.8f);
    glVertex2f(0.6f, 0.78f);
    glVertex2f(0.6f, 0.78f);
    glVertex2f(0.65f, 0.8f);

    glEnd();




    // Draw a Sun
    glColor3f(1.0f, 0.6f, 0.0f); // Purple color
    drawCircle(0.8f, 0.9f, 0.07f); // SUN
    drawText("sun", 0.8f, 0.98f);

     // first cloud
    glColor3f(1.0f, 1.0f, 1.0f); // Purple color
    drawCircle(0.55f, 0.7f, 0.04f); // cloud
    drawText("sun", 0.8f, 0.98f);

     // Draw a circle
    glColor3f(1.0f, 1.0f, 1.0f); // Purple color
    drawCircle(0.59f, 0.72f, 0.04f); // Cloud
    drawText("sun", 0.8f, 0.98f);

     // Draw a circle
    glColor3f(1.0f, 1.0f, 1.0f); // Purple color
    drawCircle(0.63f, 0.7f, 0.04f); // Cloud


      // second cloud
    glColor3f(1.0f, 1.0f, 1.0f); // Purple color
    drawCircle(0.25f, 0.8f, 0.04f); // cloud

     // Draw a circle
    glColor3f(1.0f, 1.0f, 1.0f); // Purple color
    drawCircle(0.29f, 0.82f, 0.04f); // Cloud


     // Draw a circle
    glColor3f(1.0f, 1.0f, 1.0f); // Purple color
    drawCircle(0.33f, 0.8f, 0.04f); // Cloud


     // Draw a Tree
    glColor3f(0.0f,1.0f, 0.0f); // Purple color
    drawCircle(0.25f, 0.35f, 0.05f); // tree
    drawText("Tree", 0.35f, 0.4f);

    // Draw a circle
    glColor3f(0.0f, 1.0f, 0.0f); // Purple color
    drawCircle(0.3f, 0.35f, 0.05f); // tree


    glColor3f(0.0f, 1.0f, 0.0f); // Purple color
    drawCircle(0.35f, 0.35f, 0.05f); // tree


    // Draw a tree 2
    glColor3f(0.0f, 1.0f, 0.0f); // Purple color
    drawCircle(0.50f, 0.35f, 0.05f); // tree


    // Draw a circle
    glColor3f(0.0f, 1.0f, 0.0f); // Purple color
    drawCircle(0.6f, 0.35f, 0.05f); // tree

     glColor3f(0.0f, 1.0f, 0.0f); // Purple color
    drawCircle(0.55f, 0.35f, 0.05f); // tree




    // Draw a tree  3
    glColor3f(0.0f, 1.0f, 0.0f); // Purple color
    drawCircle(0.80f, 0.35f, 0.05f); // tree


    // Draw a circle
    glColor3f(0.0f, 1.0f, 0.0f); // Purple color
    drawCircle(0.85f, 0.35f, 0.05f); // tree

     glColor3f(0.0f, 1.0f, 0.0f); // Purple color
    drawCircle(0.9f, 0.35f, 0.05f); // tree

   // draw light 1
    glColor3f(1.0f, 1.0f, 1.0f); // Purple color
    drawCircle(0.95f, 0.5f, 0.02f); // light

     // draw light 2
    glColor3f(1.50f, 1.0f, 1.0f); // Purple color
    drawCircle(0.2f, 0.5f, 0.02f); // light

    // tree base 1
    glColor3f(0.0f,0.198f, 0.1f); // tree base
    glBegin(GL_QUADS);
    glVertex2f(0.3f, 0.22f);
    glVertex2f(0.32, 0.22f);
    glVertex2f(0.32f, 0.3f);
    glVertex2f(0.3f, 0.3f);
    glEnd();

    // tree base 2
    glColor3f(0.0f,0.198f, 0.1f); // tree base
    glBegin(GL_QUADS);
    glVertex2f(0.55f, 0.22f);
    glVertex2f(0.57, 0.22f);
    glVertex2f(0.57f, 0.3f);
    glVertex2f(0.55f, 0.3f);
    glEnd();


    // tree base 3
    glColor3f(0.0f,0.198f, 0.1f); // tree base
    glBegin(GL_QUADS);
    glVertex2f(0.85f, 0.22f);
    glVertex2f(0.87, 0.22f);
    glVertex2f(0.87f, 0.3f);
    glVertex2f(0.85f, 0.3f);
    glEnd();

    //light base 1
    glColor3f(0.0f,0.0f, 0.0f); // tree base
    glBegin(GL_QUADS);
    glVertex2f(0.19, 0.22f);
    glVertex2f(0.2, 0.22f);
    glVertex2f(0.2f, 0.48f);
    glVertex2f(0.19f, 0.48f);
    glEnd();


    glPopMatrix(); // Restore previous matrix

    glFlush(); // Process buffered OpenGL routines
}

// Initialize OpenGL settings
void init() {
    glClearColor(0.0, 0.0, 0.0, 0.0); // Set background color to black
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0.0, 1.0, 0.0, 1.0, -1.0, 1.0); // Set orthographic view
}

// Update the rotation angle
void update(int value) {
    angle += 2.0f; // Increment angle
    if (angle > 360) angle -= 360; // Keep angle within 0-360

    glutPostRedisplay(); // Redraw
    glutTimerFunc(16, update, 0); // Call update every 16 ms (~60 FPS)
}

int main(int argc, char** argv) {
    glutInit(&argc, argv); // Initialize GLUT
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB); // Set display mode
    glutInitWindowSize(600, 600); // Set window size
    glutCreateWindow("Basic Shapes in OpenGL"); // Create window
    init(); // Initialize OpenGL
    glutDisplayFunc(display); // Set display callback
    glutTimerFunc(25, update, 0); // Start rotation update
    glutMainLoop(); // Enter main loop
    return 0;
}
