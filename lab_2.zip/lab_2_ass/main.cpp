#include<windows.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <math.h>
#define PI 3.14159265358979323846

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Row 1
    glColor3f(1.0f, 0.6f, 0.0f); // Triangle
    glBegin(GL_TRIANGLES);
        glVertex2f(0.07f, 0.87f);
        glVertex2f(0.13f, 0.87f);
        glVertex2f(0.10f, 0.97f);
    glEnd();

    glColor3f(0.5f, 0.8f, 0.5f); // Trapezoid
    glBegin(GL_QUADS);
        glVertex2f(0.20f, 0.87f);
        glVertex2f(0.30f, 0.87f);
        glVertex2f(0.33f, 0.97f);
        glVertex2f(0.17f, 0.97f);
    glEnd();

    glColor3f(1.0f, 0.2f, 0.2f); // Square
    glBegin(GL_QUADS);
        glVertex2f(0.37f, 0.87f);
        glVertex2f(0.47f, 0.87f);
        glVertex2f(0.47f, 0.97f);
        glVertex2f(0.37f, 0.97f);
    glEnd();

    glColor3f(0.6f, 0.4f, 0.8f); // Pentagon
    glBegin(GL_POLYGON);
        for (int i = 0; i < 5; i++) {
            float angle = 2 * PI * i / 5;
            glVertex2f(0.60f + 0.05f * cos(angle), 0.92f + 0.05f * sin(angle));
        }
    glEnd();

    // Row 2
    glColor3f(0.2f, 0.7f, 0.8f); // Hexagon
    glBegin(GL_POLYGON);
        for (int i = 0; i < 6; i++) {
            float angle = 2 * PI * i / 6;
            glVertex2f(0.10f + 0.05f * cos(angle), 0.72f + 0.05f * sin(angle));
        }
    glEnd();

    glColor3f(0.3f, 0.6f, 0.3f); // Heptagon
    glBegin(GL_POLYGON);
        for (int i = 0; i < 7; i++) {
            float angle = 2 * PI * i / 7;
            glVertex2f(0.25f + 0.05f * cos(angle), 0.72f + 0.05f * sin(angle));
        }
    glEnd();

    glColor3f(1.0f, 0.6f, 0.1f); // Octagon
    glBegin(GL_POLYGON);
        for (int i = 0; i < 8; i++) {
            float angle = 2 * PI * i / 8;
            glVertex2f(0.40f + 0.05f * cos(angle), 0.72f + 0.05f * sin(angle));
        }
    glEnd();

    glColor3f(0.7f, 0.2f, 0.2f); // Nonagon
    glBegin(GL_POLYGON);
        for (int i = 0; i < 9; i++) {
            float angle = 2 * PI * i / 9;
            glVertex2f(0.55f + 0.05f * cos(angle), 0.72f + 0.05f * sin(angle));
        }
    glEnd();

    // Row 3
    glColor3f(0.6f, 0.8f, 0.4f); // Decagon
    glBegin(GL_POLYGON);
        for (int i = 0; i < 10; i++) {
            float angle = 2 * PI * i / 10;
            glVertex2f(0.10f + 0.05f * cos(angle), 0.52f + 0.05f * sin(angle));
        }
    glEnd();

    glColor3f(0.3f, 0.4f, 0.8f); // 11-gon
    glBegin(GL_POLYGON);
        for (int i = 0; i < 11; i++) {
            float angle = 2 * PI * i / 11;
            glVertex2f(0.25f + 0.05f * cos(angle), 0.52f + 0.05f * sin(angle));
        }
    glEnd();

    glColor3f(1.0f, 0.85f, 0.1f); // 12-gon
    glBegin(GL_POLYGON);
        for (int i = 0; i < 12; i++) {
            float angle = 2 * PI * i / 12;
            glVertex2f(0.40f + 0.05f * cos(angle), 0.52f + 0.05f * sin(angle));
        }
    glEnd();

    glColor3f(0.2f, 0.6f, 0.8f); // Circle (50-gon)
    glBegin(GL_POLYGON);
        for (int i = 0; i < 50; i++) {
            float angle = 2 * PI * i / 50;
            glVertex2f(0.55f + 0.05f * cos(angle), 0.52f + 0.05f * sin(angle));
        }
    glEnd();

    glFlush();
}

void init() {
    glClearColor(1.0, 1.0, 1.0, 1.0); // white background
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0.0, 1.0, 0.0, 1.0); // coordinate system
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(1000, 1000);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Manual Shapes Drawing");
    init();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
