#include <windows.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>



// Draw filled circle
void drawCircle(float cx, float cy, float r, int segments = 100) {
    glBegin(GL_POLYGON);
    for (int i = 0; i < segments; i++) {
        float theta = 2.0f * 3.1415926f * i / segments;
        float x = r * cosf(theta);
        float y = r * sinf(theta);
        glVertex2f(cx + x, cy + y);
    }
    glEnd();
}

// To write a text function
void drawText(const char* text, float x, float y) {
    glRasterPos2f(x, y);
    for (int i = 0; text[i] != '\0'; i++) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, text[i]);
    }
}


void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    glPushMatrix();


    // Draw a white sky
    glColor3f(0.529f, 0.808f, 0.922f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.0f, 0.25f);
    glVertex2f(0.99f, 0.25f);
    glVertex2f(0.99f, 0.99f);
    glVertex2f(0.0f, 0.99f);
    glEnd();


     // Draw a building
    glColor3f(0.629f, 0.2f, 0.2f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.2f, 0.25f);
    glVertex2f(0.8f, 0.25f);
    glVertex2f(0.8f, 0.6f);
    glVertex2f(0.2f, 0.6f);
    glEnd();

    //  piller


    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.35f, 0.25f);
    glVertex2f(0.37f, 0.25f);
    glVertex2f(0.37f, 0.5f);
    glVertex2f(0.35f, 0.5f);
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.4f, 0.25f);
    glVertex2f(0.42f, 0.25f);
    glVertex2f(0.42f, 0.5f);
    glVertex2f(0.4f, 0.5f);
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.51f, 0.25f);
    glVertex2f(0.53f, 0.25f);
    glVertex2f(0.53f, 0.5f);
    glVertex2f(0.51f, 0.5f);
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.55f, 0.25f);
    glVertex2f(0.57f, 0.25f);
    glVertex2f(0.57f, 0.5f);
    glVertex2f(0.55f, 0.5f);
    glEnd();

    // door

    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.45f, 0.25f);
    glVertex2f(0.5f, 0.25f);
    glVertex2f(0.5f, 0.35f);
    glVertex2f(0.45f, 0.35f);
    glEnd();

     // windows 1
    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.23f, 0.45f);
    glVertex2f(0.26f, 0.45f);
    glVertex2f(0.26f, 0.48f);
    glVertex2f(0.23f, 0.48f);
    glEnd();

    // windows 2
    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.28f, 0.45f);
    glVertex2f(0.31f, 0.45f);
    glVertex2f(0.31f, 0.48f);
    glVertex2f(0.28f, 0.48f);
    glEnd();

    // windows 3
    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.23f, 0.4f);
    glVertex2f(0.26f, 0.4f);
    glVertex2f(0.26f, 0.43f);
    glVertex2f(0.23f, 0.43f);
    glEnd();

    // windows 4
    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.28f, 0.4f);
    glVertex2f(0.31f, 0.4f);
    glVertex2f(0.31f, 0.43f);
    glVertex2f(0.28f, 0.43f);
    glEnd();

    // windows 5
    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.28f, 0.35f);
    glVertex2f(0.31f, 0.35f);
    glVertex2f(0.31f, 0.38f);
    glVertex2f(0.28f, 0.38f);
    glEnd();

    // windows 6
    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.23f, 0.35f);
    glVertex2f(0.26f, 0.35f);
    glVertex2f(0.26f, 0.38f);
    glVertex2f(0.23f, 0.38f);
    glEnd();


    // right windows


     // windows 1
    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.63f, 0.45f);
    glVertex2f(0.66f, 0.45f);
    glVertex2f(0.66f, 0.48f);
    glVertex2f(0.63f, 0.48f);
    glEnd();

    // windows 2
    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.68f, 0.45f);
    glVertex2f(0.71f, 0.45f);
    glVertex2f(0.71f, 0.48f);
    glVertex2f(0.68f, 0.48f);
    glEnd();

    // windows 3
    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.63f, 0.4f);
    glVertex2f(0.66f, 0.4f);
    glVertex2f(0.66f, 0.43f);
    glVertex2f(0.63f, 0.43f);
    glEnd();

    // windows 4
    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.68f, 0.4f);
    glVertex2f(0.71f, 0.4f);
    glVertex2f(0.71f, 0.43f);
    glVertex2f(0.68f, 0.43f);
    glEnd();

    // windows 5
    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.68f, 0.35f);
    glVertex2f(0.71f, 0.35f);
    glVertex2f(0.71f, 0.38f);
    glVertex2f(0.68f, 0.38f);
    glEnd();

    // windows 6
    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.63f, 0.35f);
    glVertex2f(0.66f, 0.35f);
    glVertex2f(0.66f, 0.38f);
    glVertex2f(0.63f, 0.38f);
    glEnd();



    // windows
    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.23f, 0.45f);
    glVertex2f(0.26f, 0.45f);
    glVertex2f(0.26f, 0.48f);
    glVertex2f(0.23f, 0.48f);
    glEnd();
    // windows
    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.23f, 0.45f);
    glVertex2f(0.26f, 0.45f);
    glVertex2f(0.26f, 0.48f);
    glVertex2f(0.23f, 0.48f);
    glEnd();

     // Draw a building
    glColor3f(0.69f, 0.21f, 0.21f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.0f, 0.2f);
    glVertex2f(0.99f, 0.2f);
    glVertex2f(0.99f, 0.25f);
    glVertex2f(0.0f, 0.25f);
    glEnd();

      // Draw a building
    glColor3f(0.0f, 0.0f, 0.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.0f, 0.2f);
    glVertex2f(0.99f, 0.2f);
    glVertex2f(0.99f, 0.21f);
    glVertex2f(0.0f, 0.21f);
    glEnd();

    // draw windows

    glColor3f(0.0f, 0.0f, 0.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.0f, 0.2f);
    glVertex2f(0.99f, 0.2f);
    glVertex2f(0.99f, 0.21f);
    glVertex2f(0.0f, 0.21f);
    glEnd();



    //streat

    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.15f, 0.09f);
    glVertex2f(0.25f, 0.09f);
    glVertex2f(0.25f, 0.1f);
    glVertex2f(0.15f, 0.1f);
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.3f, 0.09f);
    glVertex2f(0.4f, 0.09f);
    glVertex2f(0.4f, 0.1f);
    glVertex2f(0.3f, 0.1f);
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.5f, 0.09f);
    glVertex2f(0.6f, 0.09f);
    glVertex2f(0.6f, 0.1f);
    glVertex2f(0.5f, 0.1f);
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.7f, 0.09f);
    glVertex2f(0.8f, 0.09f);
    glVertex2f(0.8f, 0.1f);
    glVertex2f(0.7f, 0.1f);
    glEnd();


    // Draw a red triangle
    glColor3f(0.629f, 0.2f, 0.4f); // Red color
    glBegin(GL_TRIANGLES);
    glVertex2f(0.33f, 0.6f);
    glVertex2f(0.63f, 0.6f);
    glVertex2f(0.45f, 0.7f);
    glEnd();

    /*// Draw a blue trapezoid
    glColor3f(0.0f, 0.0f, 1.0f); // Blue color
    glBegin(GL_QUADS);
    glVertex2f(0.2f, 0.6f);
    glVertex2f(0.5f, 0.6f);
    glVertex2f(0.4f, 0.8f);
    glVertex2f(0.3f, 0.8f);
    glEnd();


    // Draw a green pentagon
    glColor3f(0.0f, 1.0f, 0.0f); // Green color
    glBegin(GL_POLYGON);
    glVertex2f(0.7f, 0.6f);
    glVertex2f(0.9f, 0.6f);
    glVertex2f(0.85f, 0.75f);
    glVertex2f(0.75f, 0.85f);
    glVertex2f(0.65f, 0.75f);
    glEnd();
*/
    glColor3f(1.0f, 1.0f, 0.0f);
    drawText("2022-1-60-367", 0.4f, 0.9f);

    glColor3f(1.0f, 1.0f, 1.0f);
    drawText("EWU CONVETIONAL HALL", 0.33f, 0.55f);

    // Draw a sun
    glColor3f(1.0f, 1.0f, 0.0f);
    drawCircle(0.9f, 0.9f, 0.05f); // Circle


    // Draw a cloud
    glColor3f(1.0f, 1.0f, 1.0f);
    drawCircle(0.2f, 0.8f, 0.05f); // Circle

    // Draw a cloud
    glColor3f(1.0f, 1.0f, 1.0f);
    drawCircle(0.25f, 0.8f, 0.05f); // Circle

    // Draw a cloud
    glColor3f(1.0f, 1.0f, 1.0f);
    drawCircle(0.3f, 0.83f, 0.05f); // Circle



    // Draw a cloud_2
    glColor3f(1.0f, 1.0f, 1.0f);
    drawCircle(0.7f, 0.8f, 0.05f); // Circle

    // Draw a cloud
    glColor3f(1.0f, 1.0f, 1.0f);
    drawCircle(0.75f, 0.8f, 0.05f); // Circle

    // Draw a cloud
    glColor3f(1.0f, 1.0f, 1.0f);
    drawCircle(0.8f, 0.83f, 0.05f); // Circle

    // tree

    // Draw a cloud
    glColor3f(0.0f, 1.0f, 0.0f);
    drawCircle(0.1f, 0.53f, 0.05f); // Circle


    // Draw a cloud
    glColor3f(0.0f, 1.0f, 0.0f);
    drawCircle(0.1f, 0.43f, 0.08f); // Circle


    // Draw a tree 2
    glColor3f(0.0f, 1.0f, 0.0f);
    drawCircle(0.9f, 0.53f, 0.05f); // Circle


    // Draw a tree
    glColor3f(0.0f, 1.0f, 0.0f);
    drawCircle(0.9f, 0.43f, 0.08f); // Circle



    glColor3f(0.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.09f, 0.25f);
    glVertex2f(0.11f, 0.25f);
    glVertex2f(0.11f, 0.35f);
    glVertex2f(0.09f, 0.35f);
    glEnd();

    glColor3f(0.0f, 1.0f, 1.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.9f, 0.25f);
    glVertex2f(0.92f, 0.25f);
    glVertex2f(0.92f, 0.35f);
    glVertex2f(0.9f, 0.35f);
    glEnd();

    // bin
     glColor3f(0.0f, 1.0f, 0.0f); // White color
    glBegin(GL_QUADS);
    glVertex2f(0.15f, 0.25f);
    glVertex2f(0.2f, 0.25f);
    glVertex2f(0.2f, 0.35f);
    glVertex2f(0.15f, 0.35f);
    glEnd();

    glColor3f(1.0f, 1.0f, 0.0f); // White color
    drawText("use me", 0.16f, 0.3f);

    glPopMatrix(); // Restore previous matrix

    glFlush(); // Process buffered OpenGL routines
}

// Initialize OpenGL settings
void init() {
    glClearColor(0.0, 0.0, 0.0, 0.0); // Set background color to black
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0.0, 1.0, 0.0, 1.0, -1.0, 1.0); // Set orthographic view
}


int main(int argc, char** argv) {
    glutInit(&argc, argv); // Initialize GLUT
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB); // Set display mode
    glutInitWindowSize(600, 600); // Set window size
    glutCreateWindow("Basic Shapes in OpenGL"); // Create window
    init(); // Initialize OpenGL
    glutDisplayFunc(display); // Set display callback
    glutMainLoop(); // Enter main loop
    return 0;
}
